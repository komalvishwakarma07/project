<?php 
$to_mail="komalvishwakarma972@gmail.com";
$sub="Mail from XAMPP";
$body="This is just a mail from Server";
$he="MAIL FROM XAMPP";
if(mail($to_mail,$sub,$body,$he))
    echo "Sent";
else
    echo "Error";
?>