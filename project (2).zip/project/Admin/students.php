<?php 
include 'header.php'; 
include '../connect.php'; 
include('../sessioncheck.php');
$q="select * from stud_mst ";

$res=mysqli_query($cn,$q);
//$c=mysqli_num_rows($res);

?>
<html>
<head></head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
<body>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-dashboard"></i>Student Details</h1>
                <!-- <p>Start a beautiful journey here</p> -->
            </div>
            
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="row">
    <div class="col-md-12">
     
      <div class="card">
        <div class="card-header col-md-12">
          <div class="pull-left">
             <div class="pull-left">
            <a class="btn btn-primary"  href="students_ins.php">Add Student Detail</a>
          </div>
          </div>
        </div>
        <div class="card-body">

          <div class="table-responsive no-padding">
            <table id="documentstbl" class="table  table-striped table-bordered table-hover able-condensed">
              <thead>
                <tr>
                  <th >ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th >Actions</th>
                  <th >Actions</th>
                 </tr>
              </thead>
              <tbody>
              <?php 
              $i=1;
               while($row=mysqli_fetch_object($res))
              {
              ?>
                <tr>
        
                   <td><?php echo $row->stud_id;  ; ?></td>   
					<td><?php echo $row->stud_name  ; ?></td>   
					<td><?php echo $row->stud_email  ; ?></td>   
					<td><?php echo $row->stud_address  ; ?></td>   
					 <td><a href="students_edit.php?id=<?php echo $row->stud_id ;?>" ><button class="btn btn-success btn-sm" type="button"><i class="fa fa-trash-o"> View & Edit </i></button></a></td> 
					 <td><a href="students_delete.php?id=<?php echo $row->stud_id ;?>" onclick="javascript:return confirm('Are You Sure Want to Delete?');" ><button class="btn btn-danger btn-sm" type="button"><i class="fa fa-trash-o"> Delete </i></button></a></td> 
                </tr>
              <?php } ?>
              </tbody>
            </table>
          </div>

        </div>
     
      </div>
    </div>
  </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
<?Php include 'footer.php'; ?>