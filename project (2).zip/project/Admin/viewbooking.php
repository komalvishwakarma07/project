<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_booking";
$res=mysqli_query($cn,$q);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>
<html lang="en">
<head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>BOOKING TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Advanced Table
              </header>

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			  <tr>
                      <th>ID </th>
                      <th> Seller_name </th>
					  <th> Buyer_name </th>
					  <th> Property_id </th>
                      <th> Contact No. </th>
                      <th> Message </th>
           
                     
                    </thead>
			  </tr>
                     <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
    <tr>
	    <td><?php echo $row->id;  ?></td>
         <td><?php $sid=$row->seller_id;  
		$q1="select * from db_users  where id=".$sid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?></td>
<td><?php $bid=$row->buyer_id;  
		$q3="select * from db_users  where id=".$bid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->name;
		 ?></td>	
          <td><?php echo $row->property_id;  ?></td>	 
          <td><?php echo $row->contactno;  ?></td>
          <td><?php echo $row->message;  ?></td>
                        
         
                         
    </tr>
    <?php 
    }
    ?>
                      
              </table>
            </section>
          </div>
        </div>
		</main>
		
</body>

</html>