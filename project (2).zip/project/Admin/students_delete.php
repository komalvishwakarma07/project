<?php 
include '../connect.php'; 
include('../sessioncheck.php');
$q1="delete from stud_mst where stud_id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
echo "<Script Lang=javascript>"; 
echo "window.location.href = 'students.php' "; 
echo "</script>";

?>