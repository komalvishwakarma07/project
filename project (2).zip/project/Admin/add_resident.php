<?php 

include("connect.php");
include("sidebar.php");
if(isset($_REQUEST['save']))
    {                  
   		$q="insert into db_resident_types set
         resident_type='".$_REQUEST['resident_type']."' 
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'viewresident.php' "; 
echo "</script>";
        
         
    }
?>
<html>

<head>

<body>
   <main class="app-content">
    
		<div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-file-text-o"></i> ADD RESIDENT</h3>
            <section class="panel">
              <header class="panel-heading">
                Basic Forms
              </header>
              <div class="panel-body">
			  <form role="form" method="post">
                    <div class="form-group">
						<label for="exampleInputcity">Resident</label>
							<input type="text" class="form-control" placeholder="Enter Resident" name="resident_type" required>								
                  </div>
				</div>
				
                  <div class="col-md-12">
                     <button class="btn btn-info" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" onclick="javascript:history.go(-1);" href="sidebar.php"><i class="fa fa-fw fa-lg fa-times-circle"></i> Cancel</a>
                  </div> 
                </form>
          </div>
              </section> 
        </div>
		</main>
		
</body>

</html>