<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_properties";
$res=mysqli_query($cn,$q);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>
<html lang="en">
<head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>PROPERTY'S TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Advanced Table
              </header>

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			  <tr>
                      <th>ID </th>
                      <th> user name </th>
                      <th> city_name </th>
					  <th> socity_name </th>
					  <th> Area_name </th>
            <th> Resident_type </th>
            <th> property_type </th>

            <th> Image </th>
			<th>Action </th>
                   
					  
                    </thead>
			  </tr>
                     <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
    <tr>
	    <td><?php echo $row->id;  ?></td>
      <td><?php $cid=$row->user_id;  
		$q1="select * from db_users  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?></td>

         <td><?php $cid=$row->city_id;  
		$q1="select * from db_city  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->city_name;
		 ?></td>
<td><?php $cid=$row->society_id;  
		$q3="select * from db_society  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->society_name;
		 ?></td>		 
           <td><?php $cid=$row->area_id;  
		$q2="select * from db_area  where id=".$cid;
		$res2=mysqli_query($cn,$q2);
		$row2=mysqli_fetch_object($res2);
		echo $row2->areaname;
		 ?></td>	
     <td><?php $cid=$row->resident_id;  
		$q1="select * from db_resident_types  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->resident_type;
		 ?></td>
     
     <td><?php $cid=$row->properties_type_id;  
		$q1="select * from db_properties_types  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->property_type;
		 ?></td>

        <td><img src="img/<?php echo $row->propertyimage; ?>" width="30" height="25"></td>
		<td>
		<a href="pro.php?id=<?php echo $row->id;?>" class="btn btn-success">View</a>
        </td>        
    <?php 
    }
    ?>
                      
              </table>
            </section>
          </div>
        </div>
		</main>
		
</body>

</html>