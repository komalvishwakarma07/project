<?php 
include("connect.php"); 
$q1="delete from db_society where id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
echo "<Script Lang=javascript>"; 
echo "window.location.href = 'view_society.php' "; 
echo "</script>";

?>