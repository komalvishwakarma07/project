<?php 
include 'Admin/connect.php';



if(isset($_POST['hidden_id'])){
    $hidden_id=$_POST['hidden_id'];
    $properties_id=$_POST[' properties_id'];
    $message=$_POST['message'];
    $user_id=$_POST['user_id'];
   

    $u="update db_rating set 
    properties_id='$properties_id',
    message='$message',
    user_id='$user_id' where 
    id=$hidden_id";
    mysqli_query($cn,$u);
    
}
?>