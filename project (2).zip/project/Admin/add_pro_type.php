<?php
include ("sidebar.php"); 
include("connect.php");
if(isset($_REQUEST['save']))
    {                  
   		$q="insert into db_properties_types set
         property_type='".$_REQUEST['property_type']."',
         id='".$_REQUEST['id']."'
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'view_pro_type.php' "; 
echo "</script>";
        
         
    }

?>

<html>
<head>
<body>
		<main class="app-content">
			<div class="col-lg-12">
			<h3 class="page-header"><i class="fa fa-file-text-o"></i> ADD PROPERTYTYPE</h3>
				<section class="panel"
				<header class="panel-heading">
				  Basic Form
				</header>
				<div class="panel-body">
				<form role="form" method="post">
					<div class="form-group">
						<label for="ExampleInputcity">Property Type</label>
							<input type="text" class="form-control" name="property_type" placeholder="Enter Property Type" required>
					</div>
					</div>
					
					<div class="col-md-12">
                     <button class="btn btn-primary" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" onclick="javascript:history.go(-1);"><i class="fa fa-fw fa-lg fa-times-circle"></i> Cancel</a>
                  </div> 
                </form>
          </div>
			</section>
		</div>
		</main>
</body>
</html>