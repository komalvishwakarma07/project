<?php 
include("connect.php");
include ("sidebar.php"); 
 $q="select * from db_properties_types";
$res=mysqli_query($cn,$q);
?>
<html>
<html lang="en">
<head>
<script >
$(document).ready(function(){
	$("#documentstbl").DataTable();
});
</script>
</head>
<body>
	<main class="app-content">
	<div class="row">
	<div class="col-lg-12">
		<section class="panel">
			<header class="panel-heading">
			Property Type
			</header>
			
<table class="table table-striped tabel-advance tabel-hover" id="documentstbl">
	<thead>
    <tr>
        <th>id</th>
        <th>Add_property_Type</th>
		<th>Action</th>
		<th>Action</th>
     <thead>   
    </tr>
    <tbody>
	<?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
	
    <tr>
        <td><?php echo $row->id;  ?></td>
        <td><?php echo $row->property_type;  ?></td>
		
		<td>
		<a href="edit_pro_type.php?id=<?php echo $row->id;?>" class="btn btn-success">EDIT</a>
        </td>
		<td><a href="del_pro_type.php?id=<?php echo $row->id;?>" onclick="return confirm('Are you sure want to delete???')" class="btn btn-danger">DELETE</a>
		</td>
    </tr>
    <?php 
    }
    ?>
	</tbody>
</table>
</body>
</html>