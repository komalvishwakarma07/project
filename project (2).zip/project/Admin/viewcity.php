 <?php 
include("connect.php");

include("sidebar.php");
 $q="select * from db_city";
$res=mysqli_query($cn,$q);


?>

<html lang="en">
<head></head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>CITY TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Citys
              </header>

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
			  <thead>
			  <tr>
                   
                      <th>ID </th>
                      <th> City_name </th>
                      <th> ACTION </th>
					  <th> ACTION </th>
                    
					</thead>
					</tr>
					
					
                     <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
    <tr>
	    <td><?php echo $row->id;  ?></td>
        <td><?php echo $row->city_name;  ?></td>
        
                     <td>
                        
                          <a class = "btn btn-success" href="city_edit.php?id=<?php echo $row->id;?>">EDIT</a></td>
                         <td> <a class = "btn btn-danger" href="city_del.php?id=<?php echo $row->id;?>" onclick="return confirm('Are you sure want to delete???')">DELETE</a>

                        
                      </td>
    </tr>
    <?php 
    }
    ?>
                      
              </table>
            </section>
          </div>
        </div>
		</main>
		
</body>

</html>