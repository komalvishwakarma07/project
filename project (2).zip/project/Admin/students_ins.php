<?php 
include 'header.php'; 
include '../connect.php'; 
include('../sessioncheck.php');
if(isset($_REQUEST['save']))
    {                  
   		$q="insert into stud_mst set
         stud_name='".$_REQUEST['stud_name']."',
         stud_email='".$_REQUEST['stud_email']."',
         stud_address='".$_REQUEST['stud_address']."'
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'students.php' "; 
echo "</script>";
        
         
    }

?>
<html>
<head></head>
<body>
    <main class="app-content">
        <div class="app-title">
            <div>
                <h1><i class="fa fa-dashboard"></i>Student Details</h1>
                <!-- <p>Start a beautiful journey here</p> -->
            </div>
           
        </div>
        <div class="tile">           
          <div class="row">  
             <form  name="form1"  method="post" enctype="multipart/form-data">
              <div class="col-md-4">
                    <div class="form-group">
						<label >Student Name</label>
							<input type="text" class="form-control" name="stud_name" required>								
                  </div>
				</div>
				<div class="col-md-4">
                    <div class="form-group">
						<label >Student Email</label>
							<input type="text" class="form-control" name="stud_email" required>								
                  </div>
				</div>
				<div class="col-md-4">
                    <div class="form-group">
						<label >Address</label>
							<input type="text" class="form-control" name="stud_address" required>								
                  </div>
				</div>
                  <div class="col-md-12">
                     <button class="btn btn-primary" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" onclick="javascript:history.go(-1);"><i class="fa fa-fw fa-lg fa-times-circle"></i> Cancel</a>
                  </div> 
                </form>
          </div>
              
        </div>
    </main>
</body>

</html>
<?Php include 'footer.php'; ?>