<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_users";
$res=mysqli_query($cn,$q);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>
<html lang="en">
<head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>PROPERTY'S TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Advanced Table
              </header>

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			  <tr>
                      <th>ID </th>
                      <th> name </th>
					  <th> email </th>
					  <th> Image </th>
                      <th> Pincode </th>
                      <th> Conatct_no </th>
                      <th> Role_id </th>
                      <th> ACTION </th>
                   
					  
                    </thead>
			  </tr>
                     <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
    <tr>
	    <td><?php echo $row->id;  ?></td>
        <td><?php echo $row->name;?></td>
        <td><?php echo $row->email;  ?></td>
        <td><img src="img/<?php echo $row->profile; ?>" width="30" height="25"></td>
        <td><?php echo $row->pincode;?></td>
        <td><?php echo $row->conatct_no;  ?></td>
        <td><?php echo $row->role_id;  ?></td>

        <td>
                        
        <a class = "btn btn-danger" href="user_del.php?id=<?php echo $row->id;?>" onclick="return confirm('Are you sure want to delete???')">DELETE</a>

                   
    <?php 
    }
    ?>
                      
              </table>
            </section>
          </div>
        </div>
		</main>
		
</body>

</html>