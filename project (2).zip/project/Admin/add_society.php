<?php
include ("sidebar.php"); 
include("connect.php");
if(isset($_REQUEST['save']))
    {                  
   		$q="insert into db_society set
         society_name='".$_REQUEST['society_name']."'
         
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'view_society.php' "; 
echo "</script>";
        
         
    }

?>
<html>
<head>
<body>
		<main class="app-content">
			<div class="col-lg-12">
			<h3 class="page-header"><i class="fa fa-file-text-o"></i> ADD SOCIETY</h3>
				<section class="panel"
				<header class="panel-heading">
				Basic Form
				</header>
				<div class="panel-body">
				<form role="form" method="post">
					<div class="form-group">
						<label for="ExampleInputcity">Society</label>
							<input type="text" class="form-control" name="society_name" placeholder="Enter society" required>
					</div>
					</div>
					
					<div class="col-md-12">
                     <button class="btn btn-primary" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" onclick="javascript:history.go(-1);"><i class="fa fa-fw fa-lg fa-times-circle"></i> Cancel</a>
                  </div> 
                </form>
          </div>
			</section>

		</div>
		</main>
</body>
</html>