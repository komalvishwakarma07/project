<?Php 
session_start();
//error_reporting(0);
include 'connect.php';
$err="";

if(isset($_POST['btnsubmit']))
{

$sql1 = "select * from db_users where email='".$_REQUEST['txtuseremail']."' and password='".$_REQUEST['txtpassword']."' ";
  $rs1 = mysqli_query($cn,$sql1);

  if(mysqli_num_rows($rs1) > 0)
  { 

     	$_SESSION['staff'] = strtolower($_POST['txtuseremail']);
   
		  echo "<Script Lang=javascript>"; 
echo "window.location.href = 'index1.php' "; 
echo "</script>";
		
      }
      
  else
  {
    echo "<script>alert('Invalid Username or Password...');</script>";
    $err = "Invalid Login";
  }
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="CS/css/bootstrap.min.css"> 
  <link href="CS/css/font-awesome.min.css" rel="stylesheet"> 
   <link href="CS/css/main.css" rel="stylesheet" > 
   <link href="CS/css/custom.css" rel="stylesheet" > 
<link rel="shortcut icon" href="../IMG/MCA Logo1.png" />
    <title>DREAMHOUSE</title>
    <style type="text/css">
    
    
  
   
   .prop{
	   
    text-align:center;
    margin-top: 90px;
    font-size:50px;
    font-weight:bolder;
    color:gray;
  
   }
   .login-head{
	   
     text-align:center;
     font-size:50px;
     font-weight:bolder;
     color:blue;
   
    }
    body{
			background-repeat:no-repeat;
			background-size: cover;
			background-position: center center;
		}
  
   
    </style>
  </head>
  <body background="../a4.jpg">
   <!-- <section class="material-half-bg">
      <div class="cover"></div>
    </section> -->
   <!-- <section class="login-content"> -->
      <div class="logo">
        <h1 class="prop">ADMIN</h1>
		 <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>HOME / <span style="color:black">LOGIN</span</h3>
      </div>
     
      <div class="container">
                <div class="row">
                    <div class="col-md-5 mx-auto">
                        <div class="card card-body">
                          
       

 
        <form class="login-form" method="post" >
         
          <div class="form-group">
            <label class="control-label">Email</label>
            <input class="form-control" type="text"  required name="txtuseremail" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Password</label>
            <input class="form-control" type="password" required  name="txtpassword" placeholder="Password">
          </div>
		 
        
          <div class="form-group btn-container1">
            <button class="btn btn-primary " name="btnsubmit" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
           
          </div>
          
          <div class="text-center add_top_10" class="btn btn-dark"><strong><a href="../forgotpass.php"><span style="color:green">Forgot Password?</span></a></strong></div>
        </form>
      
        </div>
      </div>
      </div>
      </div>
      </div>
   
	
    <!-- Essential javascripts for application to work-->
   
    
  </body>
</html>
 <?php 
// include("../footer.php");
?>
  