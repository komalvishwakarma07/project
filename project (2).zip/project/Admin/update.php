<?php
include("connect.php");
//include("sidebar.php");



if(isset($_POST['update_status']) && isset($_POST['update_hidden'])) {
 
  $status=$_POST['update_status'];
  $hidden_id=$_POST['update_hidden'];
  $q="update db_rating set status='$status' where id=$hidden_id";

  echo json_encode($q);
  mysqli_query($cn,$q);
  
}
?>

