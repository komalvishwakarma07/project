<?php
     
    include("connect.php");
    include ("sidebar.php"); 
    include('function.php');
  
?>

<!DOCTYPE html>
<html>
<head>
	<style>
		  body{
			background-repeat:no-repeat;
			background-size: cover;
			background-position: center center;
		}

	</style>
</head>	
<body background="../a.jfif">
	
<section class="contact-us">
            <div class="grid-container" >
            
<form role="form" method="post">

	<div class="row" style="margin-left:300px; margin-top:120px">
	
	   <div class="col-md-3" >
	       <div class="card bg-light" >
				<div class="card-header bg-info" >Registered Users:</div>
				
				<div class="card-body" >
					<p class="card-text"><a href="buy.php"><img src ="img/buyer.jfif" width="45" height="45" style="margin-left:40px"> <?php echo get_user_count();?></p>
					
				</div>
			</div>
			</div>
			
			<div class="col-md-3" style="margin-left:50px;">
			<div class="card bg-light" >
				<div class="card-header bg-success">Registered Seller:</div>
				<div class="card-body">
				<p class="card-text"><a href="seller.php"><img src ="img/user.png" width="45" height="45" style="margin-left:40px" ><?php echo get_seller_count();?></p>
					
				</div>
			</div>
		</div>
		
			<div class="col-md-3" style="margin-left:50px;">
			<div class="card bg-light" >
				<div class="card-header bg-secondary">Total Property:</div>
				<div class="card-body">
					<p class="card-text"><a href="viewproperty.php"><img src="img/proprty.png" width="45" height="45" style="margin-left:40px" ><?php echo get_property_count();?></a></p>
					
				</div>
			</div>
		</div>
		</div>
		
		<div class="row"  style="margin-left:300px; margin-top:120px">
			<div class="col-md-3">
			<div class="card bg-light" >
				<div class="card-header bg-warning">Total Review:</div>
				<div class="card-body" >
					<p class="card-text"><a href="newreview.php" ><img src ="img/rating.jfif" width="45" height="50" style="margin-left:40px" ><?php echo get_review_count(); ?></a></p>
					
				</div>
			</div>
		</div>
		

		<div class="col-md-3" style="margin-left:50px;">
			<div class="card bg-light" >
				<div class="card-header">Total City:</div>
				<div class="card-body">
					<p class="card-text"><a href="viewcity.php" ><img src ="img/proprty.png" width="45" height="45" style="margin-left:40px"><?php echo get_city_count();?></p>
					
				</div>
			</div>
		</div>
		

		<div class="col-md-3" style="margin-left:50px;">
			<div class="card bg-light" >
				<div class="card-header bg-info">Total Booking:</div>
				<div class="card-body">
					<p class="card-text"><a href="viewbooking.php" ><img src="img/booking.png" width="40" height="40" style="margin-left:40px"><?php echo get_booking_count();?></p>
					
				</div>
			</div>
		</div> 

		
		
	 </div>	
</form>	
</body>

</html>