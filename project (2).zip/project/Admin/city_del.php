<?php 
include("connect.php");
$d="select *  from db_city where id=".$_GET['id']; 
$res=mysqli_query($cn,$d);
$row=mysqli_fetch_object($res);
$q="delete  from db_city where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
header("location:viewcity.php");
?>