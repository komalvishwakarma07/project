<?php 
include("connect.php");
$d="select *  from db_area where id=".$_GET['id']; 
$res=mysqli_query($cn,$d);
$row=mysqli_fetch_object($res);
$q="delete  from db_area where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
header("location:viewarea.php");
?>