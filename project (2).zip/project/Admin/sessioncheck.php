<?php
session_start();
if($_SESSION['staff']== "" || $_SESSION['staff']== null)
{
  echo "<Script Lang=javascript>"; 
echo "window.location.href = 'index1.php' "; 
echo "</script>";

	exit;
}
?>