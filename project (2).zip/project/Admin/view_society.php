<?php 
include("connect.php");
include ("sidebar.php"); 
 $q="select * from db_society";
$res=mysqli_query($cn,$q);
?>
<html>
<html lang="en">
<head>
<script >
$(document).ready(function(){
	$("#documentstbl").DataTable();
});
</script>
</head>
<body>
	<main class="app-content">
	<div class="row">
	<div class="col-lg-12">
    <h3 class="page-header"><i class="fa fa-file-text-o"></i> SOCIETY TABLE</h3>
		<section class="panel">
			<header class="panel-heading">
			society
			</header>
			
<table class="table table-striped tabel-advance tabel-hover" id="documentstbl">
	<thead>
    <tr>
        <th>id</th>
        <th>Add_society</th>
		<th>Action</th>
		<th>Action</th>
     <thead>   
    </tr>
    <tbody>
	<?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
	
    <tr>
        <td><?php echo $row->id;  ?></td>
        <td><?php echo $row->society_name;  ?></td>
		
		<td>
		<a href="edit_society.php?id=<?php echo $row->id;?>" class="btn btn-success">EDIT</a>
        </td>
		<td><a href="delete_society.php?id=<?php echo $row->id;?>" onclick="return confirm('Are you sure want to delete???')" class="btn btn-danger">DELETE</a>
		</td>
    </tr>
    <?php 
    }
    ?>
	</tbody>
</table>
</body>
</html>