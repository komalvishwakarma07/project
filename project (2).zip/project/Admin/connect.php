<?php 
$cn=mysqli_connect("localhost","root","","dreamhouse")or die("Could not connect");
?>