<?php 
// session_start(); 

$q="select * from db_users where email like '".$_SESSION['staff']."'"; 
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$bid=$row->id;



$q="select * from db_properties where id=".$_GET['id']; 
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$pid=$row->id;
$sid=$row->user_id;

$sid=$row->user_id;
if(isset($_POST['save']))
    {                  
   	echo $q1="insert into db_rating set
          rating='".$_REQUEST['rating']."'  ,
          message='".$_REQUEST['message']."'  ,
          properties_id='$pid'  ,
          user_id='$bid', 
          photo='".$_FILES['myfile']['name']."'
 		  ";

           move_uploaded_file($_FILES['myfile']['tmp_name'],"Admin/img/".$_FILES['myfile']['name']);
       $rs1 = mysqli_query($cn,$q1);
        
        
              

  
}

$q="select * from db_rating where status='approve'";
$res2=mysqli_query($cn,$q);
   
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Star rating</title>
	<style>
		
*{
	margin: 0;
	padding: 0;




}



/*styling star rating*/

.rating {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rating:not(:checked) > input {
    position:absolute;
    top:-9999px;
}

.rating > input{
	display: none;
}

.rating > label:before{
	content: '★ ';
	font-family: FontAwesome;
	margin: 5px;
	font-size: 1.5rem;
	display: inline-block;
	cursor: pointer;
}




.rating > label{
	color: #ddd;
	float: right;
	cursor: pointer;
}

.rating > input:checked ~ label,
.rating:not(:checked) > label:hover, 
.rating:not(:checked) > label:hover ~ label{
	color: #ffc700;  
}

.rating > input:checked + label:hover,
.rating > input:checked ~ label:hover,
.rating > label:hover ~ input:checked ~ label,
.rating > input:checked ~ label:hover ~ label{
	color: #c59b08;
}

.btn-warning{

position: relative;
padding: 11px 16px;
font-size: 15px;
line-height: 1.5;
border-radius: 3px;
color: white;
background-color: blue;
overflow: hidden;

}
.btn-warning input[type="file"]{
cursor: pointer;
position: absolute;
left: 0;
top: 0;
transform: scale(3);
opacity: 0;
}

.container2{
    border-radius: 4px;
    padding: 20px;
    background-color: #f2f2f2;
    width : 950px;
}
.container1{
    border-radius: 5px;
    padding: 20px;
    background-color: #f2f2f2;
    width : 950px;

}
.p{
    text-align: 10px;
    
}
   
   


	</style>
</head>
<body>


<section class="reviews comments" >
<form method="post" enctype="multipart/form-data">

<h3 class="mb-5">3 Reviews</h3>

<?php
while($row=mysqli_fetch_object($res2)){
  ?>
  <div class= "container1">
  <?php
$uid=$row->user_id;

 $q1="select * from db_users where id=$uid";
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
//print_r($row1);
//echo 

?>
                           
                           <div class="row mb-3">
                           
                                <!-- <ul class="col-12 commented pl-0"> -->
                                    <!-- <li class="comm-inf">  -->
                                       <div>
                                            
                                            <img src="Admin/img/<?php echo $row1->profile; 
  
  $q1="select distinct * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>" width="100" height="100"  style="margin-left:50px; margin-top: 30px;" class="rounded-circle"   class="img-fluid" alt="">
 </div>

                    
                                      
                                            <!-- <div class="conra" > -->
                                                <h5 class="mb-2"  style= "margin-top: -80px; margin-left: 200px; color:blue;"><?php $cid=$row->user_id;  
		$q3="select * from db_users  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->name;
		 ?> &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
         
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          &nbsp;
          

                                                <!-- <div class="rating"> -->
                                                
                                                       <?php 
                                                        
                                                        if($row->rating==1){
                                                                echo '<i class="fa fa-star"  style="color:#ffc700;">★ </i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==2){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==3){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==4){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==5){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;" >★ </i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                        }
                                                        
                                                        ?>
                                                        </h5>
                                                        
                                                    <!-- </div> -->
                                                <!-- </div> -->
                                          
                                            <p1 style= " margin-top: -50px; margin-left: 210px; color:blue;"><?php echo $row->date?></p1>
                                            <div   style="margin-top: 4px; margin-left:200px; margin-right:350px;width:750px; color:black;"><?php echo $row->message?>
                                                    </div> 
                                            
                                            <div class="rest" style="margin-left: 210px;margin-top:10px; "><img src="Admin/img/<?php echo $row->photo ?> "  width="200" height="200"  class="img-fluid" alt=""></div>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                            
                            </div>
                            </from>
                                                    </div>
                            <?php
}
?>
</div>
                        </section>
</div>
</div>
</div>

&nbsp;
<section class="single reviews leve-comments details">
<div class= "container2">
    <form method="post" enctype="multipart/form-data" >
                            <div id="add-review" class="add-review-box">
                                <!-- Add Review -->
                                <h3 class="listing-desc-headline margin-bottom-30 mb-6">Add Review</h3>
                                <span class="leave-rating-title">Your rating for this listing</span>
                                <!-- <input type="text"name="rating"> -->
                                <!-- Rating / Upload Button -->
                                <div class="row mb-4">
                                    <div class="col-md-6">
                                        <!-- Leave Rating -->
                                        <div class="clearfix"></div>
				<fieldset class="rating">
				<input type="radio" id="star5" name="rating" value="5"/><label for="star5" class="full" title="Awesome"></label>
					<!-- <input type="radio" id="star4.5" name="rating" value="4.5"/><label for="star4.5" class="half"></label> -->
					<input type="radio" id="star4" name="rating" value="4"/>
                    <label for="star4" class="full"></label>
					<!-- <input type="radio" id="star3.5" name="rating" value="3.5"/><label for="star3.5" class="half"></label> -->
					<input type="radio" id="star3" name="rating" value="3"/><label for="star3" class="full"></label>
					<!-- <input type="radio" id="star2.5" name="rating" value="2.5"/><label for="star2.5" class="half"></label> -->
					<input type="radio" id="star2" name="rating" value="2"/><label for="star2" class="full"></label>
					<!-- <input type="radio" id="star1.5" name="rating" value="1.5"/><label for="star1.5" class="half"></label> -->
					<input type="radio" id="star1" name="rating" value="1"/><label for="star1" class="full"></label>
					<!-- <input type="radio" id="star0.5" name="rating" value="0.5"/><label for="star0.5" class="half"></label> -->
				</fieldset>
			


        <div class="clearfix"></div>
                                    </div>
                                    <div class="col-md-6">
                                        <!-- Uplaod Photos -->
                                         <div class="add-review-photos margin-bottom-30">
                                            <div class="photoUpload">
                                               <button type="button" class="btn-warning">
                                                <i class="fa fa-upload"></i>upload photos
                                                <input type="file"   name="myfile">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 data">
                                        <form action="#">
                                            <div class="col-md-12">
                                               
                                          
                                            <div class="col-md-12 form-group" style="width:800px; ">
                                                <textarea class="form-control" name="message" id="exampleTextarea" rows="8" placeholder="Review" required></textarea>
                                            </div>
                                            <button type="submit" name="save" class="btn btn-primary btn-lg mt-2">Submit Review</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </section>
                        
</form>                 
	

	
</body>
</html>