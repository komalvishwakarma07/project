<?php
include("Admin/connect.php");
if(isset($_REQUEST['btnsubmit'])){
	$file = $_FILES['myfile']['name'];
	
	$q="insert into db_users(profile) values('$file')";
	
	$res= mysqli_query($cn, $q);
	
	if($res){
		 move_uploaded_file($_FILES['myfile']['tmp_name'],"$file");
	}
}
?>