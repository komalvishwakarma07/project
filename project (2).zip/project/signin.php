<?Php 
session_start();
//error_reporting(0);
include("h2.php");
include 'Admin/connect.php';

$err="";

if(isset($_POST['btnsubmit']))
{

$sql1 = "select * from db_users where email='".$_REQUEST['txtuseremail']."' and password='".$_REQUEST['txtpassword']."' ";
  $rs1 = mysqli_query($cn,$sql1);

  if(mysqli_num_rows($rs1) > 0)
  { 
    
     	$_SESSION['staff'] = strtolower($_POST['txtuseremail']);  
       
       
echo "<Script Lang=javascript>"; 
echo "window.location.href = 'index2.php' "; 
echo "</script>";
		
      }

      
  else
  {
    echo "<script>alert('Invalid Username or Password...');</script>";
    $err = "Invalid Login";
  }
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
   
    <title>VTCBCSR</title>
    <style type="text/css">
    
    
   /* form{ */
    /* text-align:left; */
    /* margin-left:50px; */
    /* margin-right:50px; */
   
   /* } */
   
   h1{
	   
    text-align:center;
    margin-top: 110px;
    font-size:50px;
    font-weight:bolder;
    color:gray;
  
   }
   h3{
	   
     text-align:center;
     font-size:50px;
     font-weight:bolder;
     color:blue;
   
    }
    /* label{ */
          /* margin: 10px; */
          /* color:black; */
          /* font: arial; */
    /* } */
    button{
      margin: 10px;
    }
    body{
			background-repeat:no-repeat;
			background-size: cover;
			background-position: center center;
		}
  
  
   
    </style>
  </head>
  <body  background="p2.jfif">
   <!-- <section class="material-half-bg">
      <div class="cover"></div>
    </section> -->
   <!-- <section class="login-content"> -->

      <div class="logo">
        <h1>LOGIN</h1>
		 <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>HOME / <span class="color-a">LOGIN</span</h3>
      </div>
     
      <div class="container">
                <div class="row">
                    <div class="col-md-5 mx-auto">
                        <div class="card card-body">
                          
      
                                                    
                            <form   method="post" data-parsley-validate="" data-parsley-errors-messages-disabled="true" novalidate="" _lpchecked="1"><input type="hidden" name="_csrf" value="7635eb83-1f95-4b32-8788-abec2724a9a4">
                            
                                <div class="form-group required">
                                    <lSabel for="username">Email</lSabel>
                                    <input type="text" class="form-control text-lowercase"  name="txtuseremail" >
                                </div>                    
                                <div class="form-group required">
                                    <label class="d-flex flex-row align-items-center" for="password">Password 
                                       </label>
                                    <input type="password" class="form-control" required  name="txtpassword" >
                                </div>
                                <div class="form-group mt-4 mb-4">
                                    <div class="custom-control custom-checkbox">
                                  
                                        <a  class="ml-auto border-link small-xl" href="forgotpass.php">Forget?</a>
                                       
                                    </div>
                                </div>
                                <div class="form-group pt-1">
                                    <button class="btn btn-primary btn-block" type="submit" name="btnsubmit">Log In</button>
                                </div>
                            </form>
                            <p class="small-xl pt-3 text-center">
                                <span class="text-muted">Not a member?</span>
                                <a href="singup.php">Sign up</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
       

     <!-- <div class="login-box">
        <form class="login-form" method="post" >
         
          <div class="form-group">
            <label class="control-label">Email</label>
            <input class="form-control" type="text"  required name="txtuseremail" placeholder="Email" autofocus>
          </div>
          <div class="form-group">
            <label class="control-label">Password</label>
            <input class="form-control" type="password" required  name="txtpassword" placeholder="Password">
          </div>
		   <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                
              </div>
              </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary " name="btnsubmit" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
           
          </div>
          <div class="text-center add_top_10" class="btn btn-dark">New to Find Houses? <strong><a href="singup.php"><span style="color:blue">Sign Up!</span></a></strong></div>
          <div class="text-right add_top_10" class="btn btn-dark"><strong><a href="forgotpass.php"><span style="color:blue">Forgot Password?</span></a></strong></div>
        </form>
      
        </div>
      </div>
    </section> 
	
    <!-- Essential javascripts for application to work-->
    
    
  </body>
</html>
<?php
include("footer.php");
?>