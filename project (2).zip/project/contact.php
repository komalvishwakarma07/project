<?php 
// session_start(); 

include("Admin/connect.php");
include("h1.php");

if(isset($_REQUEST['save']))
    {                  
   		$q="insert into db_contact set
         first_name='".$_REQUEST['firstname']."' ,
         last_name='".$_REQUEST['lastname']."' ,
         email='".$_REQUEST['email']."' ,
		  message='".$_REQUEST['message']."' 
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'index2.php' "; 
echo "</script>";
        
         
    }

?>



<main id="main">

<!-- ======= Intro Single ======= -->
<section class="intro-single">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <div class="title-single-box">
          <h1 class="title-single">Contact US</h1>
          <span class="color-text-a">Aut voluptas consequatur unde sed omnis ex placeat quis eos. Aut natus officia corrupti qui autem fugit consectetur quo. Et ipsum eveniet laboriosam voluptas beatae possimus qui ducimus. Et voluptatem deleniti. Voluptatum voluptatibus amet. Et esse sed omnis inventore hic culpa.</span>
        </div>
      </div>
      <div class="col-md-12 col-lg-4">
        <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
              Contact
            </li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</section><!-- End Intro Single-->

<!-- ======= Contact Single ======= -->
<section class="contact">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="contact-map box">
          <div id="map" class="contact-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1422937950147!2d-73.98731968482413!3d40.75889497932681!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1ses-419!2sve!4v1510329142834" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
      <div class="col-sm-12 section-t8">
        <div class="row">
          <div class="col-md-7">
            <form method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 mb-3">
                  <div class="form-group">
                    <input type="text" name="firstname" class="form-control form-control-lg form-control-a" placeholder="First Name" required>
                  </div>
                </div>
                <div class="col-md-6 mb-3">
                  <div class="form-group">
                    <input name="lastname" type="text" class="form-control form-control-lg form-control-a" placeholder="Last Name" required>
                  </div>
                </div>
                <div class="col-md-12 mb-3">
                  <div class="form-group">
                    <input type="text" name="email" class="form-control form-control-lg form-control-a" placeholder="Email" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea name="message" class="form-control" type="text" cols="45" rows="8" placeholder="Message" required></textarea>
                  </div>
                </div>
                <div class="col-md-12 my-3">
                  <div class="mb-3">
                    <div class="loading">Loading</div>
                    <div class="error-message"></div>
                    <div class="sent-message">Your message has been sent. Thank you!</div>
                  </div>
                </div>

                <div class="col-md-12 text-center">
                  <button type="submit" name="save" class="btn btn-a">Send Message</button>
                </div>
              </div>
            </form>
          </div>
         

           <div class="col-md-5 section-md-t3">
         
            <div class="icon-box section-b2">    
             
                        <!-- <div class="row"> -->
           <!-- <div class="col-md-4"> -->
          
                        
            <div class="card-box-d">
             <div class="card-img-d"> 
                <img src="Admin/img/contact.jpg"  style="height:400px;" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                 <div class="card-header-d">
                   <div class="card-title-d align-self-center"> 
                   
                       
                   <div class="call-info">
                            <h3>Contact Details</h3>
                            <p class="mb-5" style="color:red;">Please find below contact details and contact us today!</p>
                            <ul>
                                <li>
                                    <div class="info">
                                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                                        <p class="in-p" style="color:red;">95 South Park Ave, USA</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="info">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                        <p class="in-p" style="color:red;">+456 875 369 208</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="info">
                                        <i class="fa fa-envelope" aria-hidden="true"></i>
                                        <p class="in-p ti" style="color:red;">support@findhouses.com</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="info cll">
                                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                                        <p class="in-p ti" style="color:red;">8:00 a.m - 9:00 p.m</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!-- End Contact Single-->

</main><!-- End #main -->