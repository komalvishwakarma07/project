<?php 
// session_start(); 
include("h1.php");
include("Admin/connect.php");


$q="select * from db_users where email like '".$_SESSION['staff']."'"; 
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$bid=$row->id;



$q="select * from db_properties where id=".$_GET['id']; 
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$pid=$row->id;
$sid=$row->user_id;

$sid=$row->user_id;
if(isset($_POST['btnsubmit']))
    {                  
   		$q1="insert into db_booking set
          contactno='".$_REQUEST['contactno']."'  ,
          message='".$_REQUEST['message']."'  ,
          property_id='$pid'  ,
          seller_id='$sid',
          buyer_id='$bid' 
 		  ";
       $rs1 = mysqli_query($cn,$q1);
        
         
      
            
            
     echo "<Script Lang=javascript>"; 
     echo "window.location.href = 'index2.php' "; 
     echo "</script>";
         
           
               
              //echo "<Script Lang=javascript>"; 
             // echo "window.location.href = 'index2.php' "; 
             // echo "</script>";
              
        
              

  
}
   
?>

  <main id="main">

    <!-- ======= Intro Single ======= -->

    <section class="intro-single">
      <div class="container">
      <form class="form-a" method="post" enctype="multipart/form-data" >
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">304 Blaster Up</h1>
              <span class="color-text-a">Chicago, IL 606543</span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item">
                  <a href="property-grid.html">Properties</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  304 Blaster Up
                </li>
              </ol>
            </nav>
          </div>
        </div>
</form>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= Property Single ======= -->
    
    <section class="property-single nav-arrow-b">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div id="property-single-carousel" class="swiper">
              <div class="swiper-wrapper">
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->propertyimage; ?>">
                </div>
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->g1; ?>">
                </div>
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->g2; ?>">
                </div>
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->g3; ?>">
                </div>
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->g4; ?>">
                </div>
                <div class="carousel-item-b swiper-slide">
                <img src="Admin/img/<?php echo $row->g5; ?>">
                </div>
              </div>
            </div>
            <div class="property-single-carousel-pagination carousel-pagination"></div>
          </div>
        </div>
<br>

         <div class="row">
          <div class="col-sm-12">

            <div class="row justify-content-between">
              <div class="col-md-5 col-lg-4">
                <div class="property-price d-flex justify-content-center foo">
                  <div class="card-header-c d-flex">
                    <div class="card-box-ico">
                      <span class="bi bi-cash">₹</span>
                    </div>
                    <div class="card-title-c align-self-center">
                      <h5 class="title-c"><?php echo $row->price ?></h5>
                    </div>
                  </div>
                </div>
                <div class="property-summary">
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="title-box-d section-t4">
                        <h3 class="title-d">Property Details</h3>
                      </div>
                    </div>
                  </div>
 

                  <div class="summary-list">
                    <ul class="list">
        
                   <li class="d-flex justify-content-between">
                        <strong>Property ID:</strong>
                        <span><?php echo $row->id ?></span>
                      </li> 
                      <li class="d-flex justify-content-between">
                        <strong>Location:</strong>
                        <span><?php $cid=$row->area_id;  
		$q2="select * from db_area  where id=".$cid;
		$res2=mysqli_query($cn,$q2);
		$row2=mysqli_fetch_object($res2);
		echo $row2->areaname;
		 ?>,<?php $cid=$row->city_id;  
		$q3="select * from db_city  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->city_name;
		 ?> </span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Property Type:</strong>
                        <span><?php $cid=$row->properties_type_id;  
		$q3="select * from db_properties_types  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->property_type;
		 ?> </span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Status:</strong>
                        <span><?php echo $row->status ?></span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Area:</strong>
                        <span><?php echo $row->size ?>
                          <sup>2</sup>
                        </span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Beds:</strong>
                        <span><?php echo $row->Beds ?></span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Baths:</strong>
                        <span><?php echo $row->Baths ?></span>
                      </li>
                      <li class="d-flex justify-content-between">
                        <strong>Garage:</strong>
                        <span><?php echo $row->Garages ?></span>
                      </li>
                    </ul>
                  </div>
                </div>
</div>
<?php
$uid=$row->user_id;

 $q1="select * from db_users where id=$uid";
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
//print_r($row1);
//echo $row1->profile;
?>

             <div class="col-md-7 col-lg-7 section-md-t3">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="title-box-d">
                      <h3 class="title-d">Property Description</h3>
       </div>
                  </div>
                  </div>
                  <div class="property-description" ><?php echo $row->property_des ?>
</div>
             
                </div>
               
                <div class="row section-t3">
                  <div class="col-sm-12">
                    <div class="title-box-d">
                      <h3 class="title-d">Features</h3>
                    </div>
                  </div>
                </div>
                <div class="amenities-list color-text-a">
                <?php 
              $features= explode(",",$row-> feature);
              ?>
             <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("center cooling",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">center cooling  
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">
  
      <?php 
    }
    ?>
                                    
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            
                            <?php 
                                 if(in_array("Balcony",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Balcony  
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Balcony 
  
      <?php 
    }
    ?>
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Pet Friendly",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Pet Friendly 
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Pet Friendly
  
      <?php 
    }
    ?>
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Barbeque",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Barbeque
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Barbeque
  
      <?php 
    }
    ?>
                          
    
                            </div>
                           </div>
                                </div>
                            

                            <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Fire Alarm",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Fire Alarm
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Fire Alarm
  
      <?php 
    }
    ?>
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Modern Kitchen",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Modern Kitchen
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Modern Kitchen
  
      <?php 
    }
    ?>
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Storage",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Storage
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Storage
  
      <?php 
    }
    ?>
                            
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Dryer",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Dryer
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Dryer
  
      <?php 
    }
    ?>
                            

                           
                            </div>
                           </div>
                                </div>

                           <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Heating",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Heating
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Heating
  
      <?php 
    }
    ?>
                            
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Pool",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Pool
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Pool
  
      <?php 
    }
    ?>
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Laundry",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Laundry
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Laundry
  
      <?php 
    }
    ?>
                            
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Sauna",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Sauna
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Sauna
  
      <?php 
    }
    ?>
                           
                           
                            </div>
                           </div>
                                </div>
                            
                                <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Gym",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Gym
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Gym
  
      <?php 
    }
    ?>
                           
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Elevator",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Elevator
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Elevator
  
      <?php 
    }
    ?>
                         
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Dish Washer",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Dish Washer
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Dish Washer
  
      <?php 
    }
    ?>
                            
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                            <?php 
                                 if(in_array("Emergency Exit",$features)){
                                   ?>
                               <input  type="checkbox"  checked value="<?php echo $row-> feature ?>">Emergency Exit
                              <?php 
                              }
                                else
                             {
                             ?>
       <input  type="checkbox"   value="<?php echo $row-> feature ?>">Emergency Exit
  
      <?php 
    }
    ?>
                       

                            </div>
                          


                          
  
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-10 offset-md-1">
            <ul class="nav nav-pills-a nav-pills mb-3 section-t3" id="pills-tab" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="pills-video-tab" data-bs-toggle="pill" href="#pills-video" role="tab" aria-controls="pills-video" aria-selected="true">Video</a>
              </li>
            
            </ul>
            <div class="tab-content" id="pills-tabContent">
            
              <video controls  style="margin-left:50px;" src="Admin/img/<?php echo $row->video; ?>" width="700" height="400">
</video>
             
            </div>
          </div>
          <div class="col-md-12">
            <div class="row section-t3">
              <div class="col-sm-12">
                <div class="title-box-d">
                  <h3 class="title-d">Contact Agent</h3>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-lg-4">
              
              <img src="Admin/img/<?php echo $row1->profile; 
  
      $q1="select * from db_users where id=$uid";
        $res1=mysqli_query($cn,$q1);
     $row1=mysqli_fetch_object($res1);
 ?>" alt="" class="img-a img-fluid">
              </div>
              <div class="col-md-6 col-lg-4">
                <div class="property-agent">
                  <h4 class="title-agent">Anabella Geller</h4>
                  <p class="color-text-a">
                    Nulla porttitor accumsan tincidunt. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet
                    dui. Quisque velit nisi,
                    pretium ut lacinia in, elementum id enim.
                  </p>
                  <ul class="list-unstyled">
                    <li class="d-flex justify-content-between">
                      <strong>Phone:</strong>
                      <span class="color-text-a">(222) 4568932</span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Mobile:</strong>
                      <span class="color-text-a"><?php echo $row1->conatct_no; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Email:</strong>
                      <span class="color-text-a"><?php echo $row1->email; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Skype:</strong>
                      <span class="color-text-a">Annabela.ge</span>
                    </li>
                  </ul>
                  <div class="socials-a">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-lg-4">
                <div class="property-contact">
                  <form class="form-a" method="post">
                    <div class="row">
                      <div class="col-md-12 mb-1">
                        <div class="form-group">
                          <input type="text" name="contactno" class="form-control form-control-lg form-control-a" id="inputName" placeholder="contactno *" required>
                        </div>
                      </div>
                      
                      </div>
                      <div class="col-md-12 mb-1">
                        <div class="form-group">
                          <textarea id="textMessage" name="message" class="form-control" placeholder="Comment *" name="message" cols="45" rows="8" required></textarea>
                        </div>
                      </div>
                      <div class="col-md-12 mt-3">
                        <button type="submit" name="btnsubmit"class="btn btn-a">Send Message</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
      include ("rating1.php"); 

?>
    </section><!-- End Property Single-->
<?php
//include 'r1/rati.php'; 
include("footer.php");
?>
  </main><!-- End #main -->

  
  

