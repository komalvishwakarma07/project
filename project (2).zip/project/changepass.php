<?php 

//session_start(); 
//error_reporting(0);
include("Admin/connect.php");
include("h1.php");

include('sessioncheck.php');
$err="";



if(isset($_POST['btnsubmit']))
{
		$op=($_POST['password0']);
		$sqlselect = "select * from db_users where email like '".$_SESSION['staff']."' and password like '".$op."'";
		$resselect = mysqli_query($cn,$sqlselect);
		if(mysqli_num_rows($resselect) > 0)
		{
			if($_POST['password1']==$_POST['password2'])
			{
				$np=($_POST['password1']);
				$sqlupdate = "update db_users set password='".$np."' where email like '".$_SESSION['staff']."'";
			mysqli_query($cn,$sqlupdate);
			echo "<script>alert('Password changed Successfully');</script>";
			echo "<script>location.href='index2.php?res=change';</script>";
			}
			else
			{
				echo "<script>alert('New and Confirm password did not match...');</script>";
			}
			
		}
		else
		{
			echo "<script>alert('Invalid Old Password..');</script>";
		}
}

?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    
    <title>DREAMHOUSE</title>
    <style type="text/css">
    
    
   form{
    text-align:left;
    margin-left:150px;
    margin-right:150px;
   }
   
  
   h3{
	   
     text-align:center;
     font-size:50px;
     margin-top: 150px;
     font-weight:bolder;
     color:blue;
   
    }
  
  
   
    </style>
  </head>
  <body>
   <!-- <section class="material-half-bg">
      <div class="cover"></div>
    </section> -->
   <!-- <section class="login-content"> -->
      <div class="logo">
      <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Change Password ?</h3>
      </div>
     
  
       

      <div class="login-box">
        <form class="login-form" method="post" >
        
          <div class="form-group">
            <label class="control-label">Old Passsword</label>
            <input class="form-control" type="password"  required  placeholder="Old password" name="password0">
          </div>
          <div class="form-group">
            <label class="control-label">New Password</label>
            <input class="form-control" type="password" required  name="password1" placeholder="New Password">
          </div>
          <div class="form-group">
            <label class="control-label">Confirm Password</label>
            <input class="form-control" type="password" required  name="password2" placeholder="Confirm Password">
          </div>
		   <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                
              </div>
              </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary " name="btnsubmit" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>Reset</button>
          
            <a href="index2.php" class="btn btn-dark">Back</a>
           
          
           
          </div>
          
        </form>
      
        </div>
      </div>
    </section> 
	
    <!-- Essential javascripts for application to work-->
   
  </body>
</html>
<?php
include("footer.php");
?>