<?php 


$q="select * from db_properties";
$res=mysqli_query($cn,$q);
?>
 
 <head>
<link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
 <!-- ======= Latest Properties Section ======= -->
    <section class="section-property section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap d-flex justify-content-between">
              <div class="title-box">
                <h2 class="title-a">Latest Properties</h2>
              </div>
              <div class="title-link">
                <a href="property-grid.html">All Property
                  <span class="bi bi-chevron-right"></span>
                </a>
              </div>
            </div>
          </div>
        </div>
        <?php
        
        while($row=mysqli_fetch_object($res)){
          
          ?>
             
          <div id="property-carousel" class="swiper"> 
          
             
          <div class="swiper-wrapper">
         
             
         
     
            <div class="carousel-item-b swiper-slide">
              <div class="card-box-a card-shadow">
                <div class="img-box-a">
                  
                  <img src="Admin/img/<?php echo $row->propertyimage ?>" alt="" class="img-a img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-overlay-a-content">
                    <div class="card-header-a">
                      <h2 class="card-title-a">
                        <a href=""><?php $cid=$row->society_id;  
		$q3="select * from db_society  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->society_name;
		 ?> 
		
         <br /> <?php $cid=$row->area_id;  
		$q2="select * from db_area  where id=".$cid;
		$res2=mysqli_query($cn,$q2);
		$row2=mysqli_fetch_object($res2);
		echo $row2->areaname;
		 ?>	 </a>
                      </h2>
                    </div>
                    <div class="card-body-a">
                      <div class="price-box d-flex">
                        <span class="price-a"><?php echo $row->status ?> | ₹ <?php echo $row->price ?></span>
                      </div>
                      <a href="prosingle.php?id=<?php echo  $row-> id; ?>" class="link-a">Click here to view
                        <span class="bi bi-chevron-right"></span>
                      </a>
                    </div>
                    <div class="card-footer-a">
                      <ul class="card-info d-flex justify-content-around">
                        <li>
                          <h4 class="card-info-title">Area</h4>
                          <span><?php echo $row-> size ?>
                            <sup>2</sup>
                          </span>
                        </li>
                        <li>
                          <h4 class="card-info-title">Beds</h4>
                          <span><?php echo $row->Beds ?></span>
                        </li>
                        <li>
                          <h4 class="card-info-title">Baths</h4>
                          <span><?php echo $row->Baths ?></span>
                        </li>
                        <li>
                          <h4 class="card-info-title">Garages</h4>
                          <span><?php echo $row->Garages ?></span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div><!-- End carousel item -->

           
          </div>
        </div>
        <div class="propery-carousel-pagination carousel-pagination"></div>
       
      </div>
      <?php
}
?>
    </section><!-- End Latest Properties Section -->
