<?Php 
//session_start();
//error_reporting(0);
include("h1.php");
include 'Admin/connect.php';

$u= $_SESSION['staff']; 
$q="select * from db_users where email like '$u'";
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$uid=$row->id;




if(isset($_POST['add']))


    {   
        $brand = $_POST["brands"]  ;
        $lang=implode(",",$brand);             
   	echo 	$q="insert into db_properties set
          city_id='".$_REQUEST['city']."'  ,
          user_id='$uid'  ,
         area_id='".$_REQUEST['area']."'  ,
         society_id='".$_REQUEST['society']."'  ,
         resident_id='".$_REQUEST['resident_type']."'  ,
         properties_type_id='".$_REQUEST['property_type']."'  ,
		  status='".$_REQUEST['status']."',
          price='".$_REQUEST['price']."',
          size='".$_REQUEST['size']."',
          Beds='".$_REQUEST['Beds']."',
          Baths='".$_REQUEST['Baths']."',
          Garages='".$_REQUEST['Garages']."',
          property_des='".$_REQUEST['message']."',
            feature='$lang',

      propertyimage='".$_FILES['myfile']['name']."',
      g1='".$_FILES['img1']['name']."',
      g2='".$_FILES['img2']['name']."',
      g3='".$_FILES['img3']['name']."',
      g4='".$_FILES['img4']['name']."',
      g5='".$_FILES['img5']['name']."',
      video='".$_FILES['img6']['name']."'
      
 		  ";

       move_uploaded_file($_FILES['myfile']['tmp_name'],"admin/img/".$_FILES['myfile']['name']);
       move_uploaded_file($_FILES['img1']['tmp_name'],"admin/img/".$_FILES['img1']['name']);
       move_uploaded_file($_FILES['img2']['tmp_name'],"admin/img/".$_FILES['img2']['name']);
       move_uploaded_file($_FILES['img3']['tmp_name'],"admin/img/".$_FILES['img3']['name']);
       move_uploaded_file($_FILES['img4']['tmp_name'],"admin/img/".$_FILES['img4']['name']);
       move_uploaded_file($_FILES['img5']['tmp_name'],"admin/img/".$_FILES['img5']['name']);
       move_uploaded_file($_FILES['img6']['tmp_name'],"admin/img/".$_FILES['img6']['name']);

      
       $rs1 = mysqli_query($cn,$q);
        
      
            
            
     echo "<Script Lang=javascript>"; 
     echo "window.location.href = 'index2.php' "; 
     echo "</script>";
         
           
               
              //echo "<Script Lang=javascript>"; 
             // echo "window.location.href = 'index2.php' "; 
             // echo "</script>";
              
        
              

  
}

?>




<style type="text/css">
     
    .prop{
        margin-top: 200px;
        font-size:40px;
        font-weight:bolder;
        color:navy blue;
        margin-left:400px;
     }
     .y{
       
     margin-top: 50px;
      font-size:25px;
      font-weight:bolder;
      color:black;
    
     }
    
    
     body{
			background-repeat:no-repeat;
			background-size: cover;
			background-position: center center;
		}
  
  
   
    </style>
  </head>
  <body  background="p3.jfif">
    
   
    
    


<section class="contact-us">
            <div class="grid-container" >
            
                <div class="row">
                    <div class="row-lg-4">
                        <h3 class="mb-4 prop">ADD PROPERTY</h3>
                        <form  method="post" class="" enctype="multipart/form-data">
                           <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>City</lable>
                            <select style="" name="city" class="form-control" >
                                    <option value="">Select City</option>
                                        <?php 
                                              $q="select * from db_city";
                                                        $res=mysqli_query($cn,$q);
                                              
                                            while($row=mysqli_fetch_object($res))
                                            {
                                                echo "<option value=".$row-> id.">".$row->city_name."</option>";
                                            }
                                      ?>
                                </select>
    
                            </div>
                           </div>

                         
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Area</lable>
                            <select style="" name="area" class="form-control" >
                                    <option value="">Select Area</option>
                                        <?php 
                                              $q="select * from db_area";
                                                        $res=mysqli_query($cn,$q);
                                              
                                            while($row=mysqli_fetch_object($res))
                                            {
                                                echo "<option value=".$row-> id.">".$row->areaname."</option>";
                                            }
                                      ?>
                                </select>
    
                            </div>
                           
                            </div>

                            
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>society</lable>
                            <select style="" name="society" class="form-control" >
                            <option value="">SOCIETY_NAME</option>
                                    <?php 
					                         $q="select * from db_society";
                                                  $res=mysqli_query($cn,$q);
					 
                                         while($row=mysqli_fetch_object($res))
                                      {
                                          echo "<option value=".$row-> id.">".$row->society_name."</option>";
                                      }
                                    ?>
                                </select>
    
                            </div>
                           
                            </div>
                                        </div>
                            
                            <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>resident_type</lable>
                            <select  name="resident_type" class="form-control" >
                                    <option value="">SELECT RESIDENT_TYPE </option>
                                    <?php 
					                    $q="select * from db_resident_types";
                                             $res=mysqli_query($cn,$q);
					 
                                        while($row=mysqli_fetch_object($res))
                                       {
                                            echo "<option value=".$row-> id.">".$row->resident_type."</option>";
                                       }
                                    ?>
                            </select>
    
                            </div>
                           </div>

                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable> propertytype</lable>
                            <select  name = "property_type" class="form-control" >
                                <option value = "">PROPERTYTYPE</option>
                                <?php 
					                $q="select * from db_properties_types";
                                    $res=mysqli_query($cn,$q);
					 
                                    while($row=mysqli_fetch_object($res))
                                  {
                                       echo "<option value=".$row-> id.">".$row->property_type."</option>";
                                  }
                                 ?>
                            </select>
    
                            </div>
                           
                            </div>

                            <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>status </lable>
                            <select  name = "status" class="form-control" > status
                                    <option value = "">SELECT STATUS</option>
                                    <option value="SELL">SELL</option>
                                    <option value="RENT">RENT</option>
                            </select>
    
                            </div>
                           
                            </div>
                                </div>

                           <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Price</lable>
                            <input  type="text" class="form-control input-custom input-full" name="price" placeholder="" value  = "">
    
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Size</lable>
                            <input  type="text"  class="form-control input-custom input-full" name="size" placeholder="sq. ft" value="">
    
                            </div>
                           </div>
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Beds</lable>
                            <input  type="text"  class="form-control input-custom input-full" name="Beds" placeholder="" value="">
    
                            </div>
                           </div>
                                </div>

                           <div class="row">
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Baths</lable>
                            <input  type="number"  class="form-control input-custom input-full" name="Baths" placeholder="" value="">
                                
    
                            </div>
                           </div>
                          
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Garages</lable>
                            <input  type="number"  class="form-control input-custom input-full" name="Garages" placeholder="" value="">
                            </div>
                           </div>
                          
                           <div class="col-md-3">
                            <div class="form-group">
                                    
                            <lable>Property Description</lable>
                            <textarea  id="textMessage" name="message" class="form-control" placeholder=""  cols="30" rows="3" required></textarea>
    
                            </div>
                           </div>
                                </div>

                                <h3 class="mb-4 pro">PROPERTY FEATURES</h3>
                       
                           <div class="row">
                           <div class="col-md-2">
                            <div class="form-group">
                                    
                            <input  type="checkbox" name="brands[]"  value="center cooling" >center cooling
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input   type="checkbox" name="brands[]"   value="Balcony">Balcony
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Pet Friendly">Pet Friendly
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Barbeque">Barbeque
    
                            </div>
                           </div>
                                </div>
                            

                            <div class="row">
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Fire Alarm">Fire Alarm
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input type="checkbox" name="brands[]"  value="Modern Kitchen" >Modern Kitchen
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input type="checkbox" name="brands[]"  value="Storage">Storage
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Dryer">Dryer

                           
                            </div>
                           </div>
                                </div>

                           <div class="row">
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Heating">Heating
                           
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Pool">Pool
                           
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]" value="Laundry">Laundry
                           
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Sauna">Sauna
                           
                            </div>
                           </div>
                                </div>
                            
                                <div class="row">
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Gym">Gym
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Elevator">Elevator
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value="Dish Washer">Dish Washer
                            </div>
                           </div>
                           <div class="col-md-2">
                            <div class="form-group">
                            <input  type="checkbox" name="brands[]"  value=">Emergency Exit">Emergency Exit


                            </div>
                           </div>
                                </div>
                                <h3 class="mb-4 proS">PROPERTY GALLARY</h3>
                       
                       <div class="row">
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Feature Image:</label>
                        <input type="file" name="myfile"  class="form-control input-custom input-full">

                        </div>
                       </div>

                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Gallary Image1:</label>
                        <input type="file" name="img1"  class="form-control input-custom input-full">

                        </div>
                       </div>
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Gallary Image2:</label>
                        <input type="file" name="img2"  class="form-control input-custom input-full">

                        </div>
                       </div>
                            </div>
                             
                       <div class="row">
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Gallary Image3:</label>
                        <input type="file" name="img3"  class="form-control input-custom input-full">

                        </div>
                       </div>
 
                      
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Gallary Image5:</label>
                        <input type="file" name="img4"  class="form-control input-custom input-full">

                        </div>
                       </div>

                        
                     
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Gallary Image5:</label>
                        <input type="file" name="img5"  class="form-control input-custom input-full">

                        </div>
                       </div>
                                </div>
                            
                        <div class="row">
                       <div class="col-md-3">
                        <div class="form-group">
                        <label  for = "price">Video:</label>
                        <input type="file" name="img6"  class="form-control input-custom input-full">

                        </div>
                       </div>
                                </div>

                        <div class="row">

                        <div class="form-group">
                        <input  type="submit"  name="add" value ="ADD"  class="btn btn-primary btn-lg">

                        <a href="index2.php" class="btn btn-dark">Back</a>

                        </div>
                       </div>


                            
                          <!-- <div class="col-md-4">
                            <div class="form-group">
                                    
                            <lable>City</lable>
                            <input type="text" name="" id="" class="form-control">
                            </div>
                           </div>

                           <div class="col-md-4">
                            <div class="form-group">
                                    
                            <lable>City</lable>
                            <input type="text" name="" id="" class="form-control">
                            </div>
                           </div> -->

                           </div>
                        </form>   
                           
                    </div>
                </div>
            
            </div>
        </section>
          <!-- Essential javascripts for application to work-->
   
<?php 
include("footer.php");

?>