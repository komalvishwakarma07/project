<?php 
// session_start(); 
// error_reporting(0);
include("Admin/connect.php");
include("h1.php");
$u= $_SESSION['staff']; 
$q="select * from db_users where email like '$u'";
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$img=$row->profile;
$role=$row->role_id;

if(isset($_REQUEST['btnsubmit']))
    {                  
   		$q1="update db_users set
          name='".$_REQUEST['fullName']."',
          pincode='".$_REQUEST['pincode']."',
          email='".$_REQUEST['email']."',
          conatct_no='".$_REQUEST['phone']."',
          profile='".$_FILES['myfile']['name']."'
		 where email like '$u'";

    move_uploaded_file($_FILES['myfile']['tmp_name'],"Admin/img/".$_FILES['myfile']['name']);
            $res1=mysqli_query($cn,$q1);

 echo "<Script Lang=javascript>"; 
echo "window.location.href = 'index2.php' "; 
echo "</script>";

        
         
    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  
<style type="text/css">

  
    
   
   h1{
	   
     text-align:center;
     margin-top: 90px;
     font-size:50px;
     font-weight:bolder;
     color:darkblue;
   
    }
    h2{
      
        color:darkblue;
    
     }
     .btn-sm{

      position: relative;
padding: 9px 12px;
font-size: 13px;
line-height: 1.5;

color: white;
background-color: blue;
overflow: hidden;


}
.btn-sm input[type="file"]{
cursor: pointer;
position: absolute;
left: 0;
top: 0;
transform: scale(3);
opacity: 0;
}
  
   
    </style>
  
  </head>
  <body>


<main id="main" class="main">

    <div class="pagetitle">
      <h1>Profile</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Users</li>
          <li class="breadcrumb-item active">Profile</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section profile">
      <div class="row">
        <div class="col-xl-4">

          <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

              <img src="Admin/img/<?php echo $img; ?>" width="100" height="100" alt="Profile" class="rounded-circle">
              <h2><?php echo $row->name ?></h2>
              
              <div class="social-links mt-2">
                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

        </div>

        <div class="col-xl-8">

          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                </li>

                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Edit Profile</button>
                </li>

                

              </ul>
              <div class="tab-content pt-2">

                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                  <h5 class="card-title" style="margin-top: 30px; color:blue;">About</h5>
                  <p class="small fst-italic">Sunt est soluta temporibus accusantium neque nam maiores cumque temporibus. Tempora libero non est unde veniam est qui dolor. Ut sunt iure rerum quae quisquam autem eveniet perspiciatis odit. Fuga sequi sed ea saepe at unde.</p>

                  <h5 class="card-title" style="margin-top: 30px; color:Orange;">Profile Details</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label " style="margin-top: 30px; color:blue;">Full Name</div>
                    <div class="col-lg-9 col-md-8" style="margin-top: 30px;"> <?php echo $row->name ?></div>
                  </div>


                  <div class="row">
                    <div class="col-lg-3 col-md-4 label" style="margin-top: 30px; color:blue;">Pincode</div>
                    <div class="col-lg-9 col-md-8" style="margin-top: 30px;"><?php echo $row->pincode ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label" style="margin-top: 30px; color:blue;">Phone</div>
                    <div class="col-lg-9 col-md-8" style="margin-top: 30px;"><?php echo $row->conatct_no ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label" style="margin-top: 30px; color:blue;">Email</div>
                    <div class="col-lg-9 col-md-8" style="margin-top: 30px;"><?php echo $row->email ?></div>
                  </div>

                </div>

                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                  <!-- Profile Edit Form -->
                  <form method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                      <label for="profileImage" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Profile Image</label>
                      <div class="col-md-8 col-lg-9">
                      <img src="Admin/img/<?php echo $img; ?> " width="100" height="100">
                        <div class="photoupload">
                          <a href="#"     class="btn btn-primary btn-sm" title="Upload new profile image"><i class="bi bi-upload"></i>
                          <input type="file" accept="image/*" name="myfile" ></a>

                        
                          <a href="#" class="btn btn-danger btn-si" title="Remove my profile image"><i class="bi bi-trash"></i></a>
                        </div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="fullName" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Full Name</label>
                      <div class="col-md-8 col-lg-9" >
                        <input name="fullName" type="text" class="form-control" id="fullName" value="<?php echo $row->name ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="about" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">About</label>
                      <div class="col-md-8 col-lg-9">
                        <textarea name="about" class="form-control" id="about" style="height: 100px">Sunt est soluta temporibus accusantium neque nam maiores cumque temporibus. Tempora libero non est unde veniam est qui dolor. Ut sunt iure rerum quae quisquam autem eveniet perspiciatis odit. Fuga sequi sed ea saepe at unde.</textarea>
                      </div>
                    </div>


                    <div class="row mb-3">
                      <label for="Address" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Pincode</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="pincode" type="text" class="form-control" id="pincode" value="<?php echo $row->pincode ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Phone" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Phone</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="phone" type="text" class="form-control" id="Phone" value="<?php echo $row->conatct_no ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Email" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Email</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="email" type="email" class="form-control" id="Email" value="<?php echo $row->email ?>">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Twitter" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Twitter Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="twitter" type="text" class="form-control" id="Twitter" value="https://twitter.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Facebook" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Facebook Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="facebook" type="text" class="form-control" id="Facebook" value="https://facebook.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Instagram" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Instagram Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="instagram" type="text" class="form-control" id="Instagram" value="https://instagram.com/#">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="Linkedin" class="col-md-4 col-lg-3 col-form-label" style="color:darkblue;">Linkedin Profile</label>
                      <div class="col-md-8 col-lg-9">
                        <input name="linkedin" type="text" class="form-control" id="Linkedin" value="https://linkedin.com/#">
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="submit" name="btnsubmit" class="btn btn-primary">Save Changes</button>
                    </div>
                  </form><!-- End Profile Edit Form -->

                </div>

               

                

                    

                </div>

                
              </div><!-- End Bordered Tabs -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
  </div>
    