<?php 
// session_start(); 
// error_reporting(0);
include("Admin/connect.php");
include("h2.php");
$q="select distinct user_id from db_properties ";
$res=mysqli_query($cn,$q);

 

   
 ?>


<section class="section-about">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 position-relative">
            <div class="about-img-box">
              <img src="assets/img/slide-about-1.jpg" alt="" class="img-fluid">
            </div>
            <div class="sinse-box">
              <h3 class="sinse-title">DreamHouse
                <span></span>
                <br> Sinse 2023
              </h3>
              <p>Art & Creative</p>
            </div>
          </div>
          <div class="col-md-12 section-t8 position-relative">
            <div class="row">
              <div class="col-md-6 col-lg-5">
                <img src="assets/img/about-2.jpg" alt="" class="img-fluid">
              </div>
              <div class="col-lg-2  d-none d-lg-block position-relative">
                <div class="title-vertical d-flex justify-content-start">
                  <span>DreamHouse Exclusive Property</span>
                </div>
              </div>
              <div class="col-md-6 col-lg-5 section-md-t3">
                <div class="title-box-d">
                  <h3 class="title-d">Sed
                    <span class="color-d">porttitor</span> lectus
                    <br> nibh.
                  </h3>
                </div>
                <p class="color-text-a">
                  Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vivamus magna justo, lacinia eget
                  consectetur sed, convallis
                  at tellus. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Vestibulum
                  ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit
                  neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.
                </p>
                <p class="color-text-a">
                  Sed porttitor lectus nibh. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.
                  Mauris blandit aliquet
                  elit, eget tincidunt nibh pulvinar a. Vivamus magna justo, lacinia eget consectetur sed,
                  convallis at tellus.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- =======Team Section ======= -->
    <section class="section-agents section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap d-flex justify-content-between">
              <div class="title-box">
                <h2 class="title-a">Meet Our Team</h2>
              </div>
            </div>
          </div>
        </div>
        <div class="container">


<div class="row">
              <?php
while($row=mysqli_fetch_object($res)){
  ?>
       

<?php
$uid=$row->user_id;

 $q1="select * from db_users where id=$uid";
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
//print_r($row1);
//echo 

?>
          <div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
              <img src="Admin/img/<?php echo $row1->profile; 
  
  $q1="select distinct * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>" alt="" class="img-a img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two"><?php echo $row1->name; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>
                        <br></a>
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +<?php echo $row1->conatct_no; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>
                    </p>
                    <p>
                      <strong>Email: </strong> <?php echo $row1->email; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php
          }
        ?>  
     
        </div>
      </div>
    </section>